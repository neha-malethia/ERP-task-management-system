
import express from 'express';
const updateUserRouter = express.Router();




export default updateUserRouter;