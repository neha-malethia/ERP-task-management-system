import Body from './body';
function Teacher() {
    return (
        <section style={{ width: "100%" }} >
            <Body />
        </section>
    )
}
export default Teacher