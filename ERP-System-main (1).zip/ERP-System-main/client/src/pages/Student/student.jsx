
import Body from './body';

function Student() {
    return (
        <section style={{width:"100%"}} >
            <Body />
        </section>
    )
}
export default Student