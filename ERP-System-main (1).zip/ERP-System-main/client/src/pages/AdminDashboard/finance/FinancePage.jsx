import Finance from "../../../components/Admin/Finance/Finance";

export default function FinancePage() {
    return (
        <section className="vh-100  overflow-y-scroll py-3 " style={{paddingBottom:"4rem"}} >
            <Finance />
        </section>
    )
}
