import React from 'react'

const Schedule = () => {
  return (
    <div>
      Schedule page goes here
    </div>
  )
}

export default Schedule
