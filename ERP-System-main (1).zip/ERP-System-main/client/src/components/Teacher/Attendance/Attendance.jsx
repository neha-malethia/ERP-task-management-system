import React from 'react'

const AttendanceT = () => {
  return (
    <div>
      Attendance Management page goes here
    </div>
  )
}

export default AttendanceT
