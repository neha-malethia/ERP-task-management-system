import React from 'react'

const StudentReport = () => {
  return (
    <div>
      StudentReport page goes here
    </div>
  )
}

export default StudentReport
