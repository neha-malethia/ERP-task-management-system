import TeacherForm from "./TeacherForm";

const TeacherProfile = () => {

  return (
    <>
    <TeacherForm/>
    </>
  )

};
export default TeacherProfile;