import Calendar from "../../../../common/calendar/Calendar";

export default function CalenderThings() {
    return (
        <div style={{ width: "30%" }} className=" " >
            <Calendar />
        </div>
    )
}
