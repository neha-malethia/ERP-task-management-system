import React from 'react'

const FacultyFeedback = () => {
  return (
    <div>
      FacultyFeedback page goes here
    </div>
  )
}

export default FacultyFeedback
