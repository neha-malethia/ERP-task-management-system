import React from 'react'

const VirtualClass = () => {
  return (
    <div>
      VirtualClass page goes here
    </div>
  )
}

export default VirtualClass
