import React from 'react'

const Attendance = () => {
  return (
    <div>
      Attendance Management page goes here
    </div>
  )
}

export default Attendance
