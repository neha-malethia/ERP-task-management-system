import React from 'react'

const GradeAndReport = () => {
  return (
    <div>
      GradeAndReport page goes here
    </div>
  )
}

export default GradeAndReport
